Cool game by Llu�s Moreu

v.1.0 SQUARE_MOVES

CHECK OUT MY WEB IF YOU HAVE ANY QUESTIONS:

https://youis11.github.io/helloworld/

OR YOU CAN ALSO ASK ME VIA MAIL:

lluis.moreu@gmail.com